package com.project.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Amount {
	
	@Id
	@GeneratedValue
	private int id;
	
	private float mdues;
	private float general;
	private float building;
	private float common;
	private float charges;
	private String others;
	public String getothers() {
		return others;
	}
	public void setothers(String others) {
		this.others = others;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getMdues() {
		return mdues;
	}
	public void setMdues(float mdues) {
		this.mdues = mdues;
	}
	public float getGeneral() {
		return general;
	}
	public void setGeneral(float general) {
		this.general = general;
	}
	public float getBuilding() {
		return building;
	}
	public void setBuilding(float building) {
		this.building = building;
	}
	public float getCommon() {
		return common;
	}
	public void setCommon(float common) {
		this.common = common;
	}
	public float getCharges() {
		return charges;
	}
	public void setCharges(float charges) {
		this.charges = charges;
	}
	public Amount() {
		// TODO Auto-generated constructor stub
	}
	public Amount(float mdues, float general, float building, float common, float charges, String others) {
		super();
		this.mdues = mdues;
		this.general = general;
		this.building = building;
		this.common = common;
		this.charges = charges;
		this.others = others;
	}
	

}
