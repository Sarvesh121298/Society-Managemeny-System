package com.project.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class OnlinePayment {
	
	@Id
	@GeneratedValue
	private int id;
	private String date;
	private String street;
	private String city;
	private String country;
	private String zipcode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public OnlinePayment() {
		// TODO Auto-generated constructor stub
	}
	
	public OnlinePayment(String date, String street,String city, String country, String zipcode) {
		super();
		this.date=date;
		this.street = street;
		this.city = city;
		this.country = country;
		this.zipcode = zipcode;
	}

}
