package com.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.model.*;

public interface accountrepository extends JpaRepository<Account,Integer>{
	
	List<Account> findByStatus(String status);
	
	List<Account> findByRid(int rid);
	
	@Query("select u from Account u where u.rid = :rid and u.status = :status")
	List<Account> findByStatusId(@Param("rid") int rid,@Param("status") String status);
	

}
