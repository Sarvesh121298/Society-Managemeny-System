package com.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.project.model.*;

public interface suggestionrepository extends JpaRepository<Suggestion,Integer> {
	
	List<Suggestion> findByRid(int rid);
	
	List<Suggestion> findByStatus(String status);
}
