package com.project;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import com.project.model.Member;
import com.project.repository.memberrepository;

@SpringBootApplication
@EnableDiscoveryClient
public class MembersApplication implements CommandLineRunner {
	
	@Autowired
	memberrepository mrespo;

	public static void main(String[] args) {
		SpringApplication.run(MembersApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	/*	
		Member m1=new Member("Admin@123","admin","Admin","","Admin",1,101,4,8919230467L,"Admin@123");
		Member m2=new Member("Avinash1102","commitie","Avinash"," ","Pilla",1,102,4,8919230767L,"Avinash@123");
		Member m3=new Member("Naresh1103","society","Naresh","Kumar","Challa",1,103,3,9080872367L,"Naresh@123");
		List<Member> members= new ArrayList<Member>();
		members.add(m1);
		members.add(m2);
		members.add(m3);
		mrespo.saveAll(members);*/
	}

}
