package com.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.exception.ResourceNotFoundException;
import com.project.model.Member;
import com.project.repository.memberrepository;
import com.project.service.memberservice;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class Controller {

	@Autowired
	memberrepository mrespo;
	
	@Autowired
	memberservice service;
	
	@PostMapping("/mlogin")
	public Object memberlogin(@ModelAttribute("uid") String uid,@ModelAttribute("password") String password) {
		Boolean b=service.verifyuserlogin(uid, password);
		Map<String,Object> object = new HashMap<>();
		if(b) {
			Member member= mrespo.findByUid(uid);
			String type= member.getMtype();
			String  userid=member.getUid();
			String name= member.getFname();
			object.put("success","true");
			object.put("type", type);
			object.put("uid",userid);
			object.put("name", name);
			object.put("rid", member.getId());
		}
		else
			object.put("success","fail");
		return object;
		
	}
	@PostMapping("/member")
	public Member addmember(@ModelAttribute("mtype") String mtype,@ModelAttribute("fname") String fname,@ModelAttribute("mname") String mname,
			@ModelAttribute("lname") String lname,@ModelAttribute("wingno") int wingno,@ModelAttribute("flatno") int flatno,
			@ModelAttribute("count") int count,@ModelAttribute("number") long number) {
		String uid=fname+Integer.toString(wingno)+Integer.toString(flatno);
		String password=fname+"@123";
		Member member= new Member(uid,mtype,fname,mname,lname,wingno,flatno,count,number,password);
		return mrespo.save(member);	
	}
	@GetMapping("/getAllMembers")
	public List<Member> getAll(){
		return mrespo.findAll();
	}
	@GetMapping("/getmemberBycommitie")
	public List<Member> getCommititemembers() {
		String mtype="commitie";
		List<Member> members= mrespo.findByMtype(mtype);
		return members;
		
	}
	@GetMapping("/getmemberBysociety")
	public List<Member> getSocietymembers() {
		String mtype="society";
		List<Member> members= mrespo.findByMtype(mtype);
		return members;
		
	}
	@PutMapping("/member/{id}")
	public ResponseEntity<Member> editdetatils(@PathVariable int id,@RequestBody Member member) {
		
		Member mem= mrespo.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("The member is not listed with the id:"+id));
		
		mem.setFname(member.getFname());
		mem.setMname(member.getMname());
		mem.setLname(member.getLname());
		mem.setWingno(member.getWingno());
		mem.setFlatno(member.getFlatno());
		mem.setCount(member.getCount());
		mem.setPassword(member.getPassword());
		
		Member updatemember= mrespo.save(mem);
		return ResponseEntity.ok(updatemember);
	}
	@GetMapping("/member/{id}")
	public ResponseEntity<Member> getmember(@PathVariable int id){
		
		Member member=mrespo.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("The member is not listed with the id:"+id));
		return ResponseEntity.ok(member);
		
	}
	@DeleteMapping("/member/{id}")
	public ResponseEntity<Map<String,Boolean>> deletemember(@PathVariable int id){
		
		Member member=mrespo.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("The member is not listed with the id:"+id));
		mrespo.delete(member);
		Map<String,Boolean> result=new HashMap<>();
		result.put("deleted",Boolean.TRUE);
		return ResponseEntity.ok(result);
		
	}
	
}
