package com.project;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import com.project.model.Participants;
import com.project.model.Voting;
import com.project.repository.participantrepository;
import com.project.repository.votingrepository;

@SpringBootApplication
@EnableDiscoveryClient
public class VotingApplication implements CommandLineRunner {
	
	@Autowired
	participantrepository prespo;
	
	@Autowired
	votingrepository vrespo;

	public static void main(String[] args) {
		SpringApplication.run(VotingApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		/*
		List<Integer> id= new ArrayList<Integer>();
		
		id.add(3);
		id.add(2);
		
		Participants p1= new Participants(1234,id);
		
		Voting v= new Voting(1234,"President","2-4-2023","9:00","16:00");
		
		vrespo.save(v);
		prespo.save(p1);*/
		
		
	}

}
