import './App.css';
import React, { useEffect } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { useRecoilState } from "recoil";

import { isAlert, isUserLoggedInState, userIdState, userNameState, userTypeState } from "./atoms";
import { auth } from './utils/auth';

import Home from './components/Home';
import Login from './components/Login';
import Nav from './components/Nav';
import pageNotFound from './components/pageNotFound';

import Accounting from './components/Menus/Accounting';
import Bulletin from './components/Menus/Bulletin';
import CommunityWiki from './components/Menus/CommunityWiki';
import ComplientSuggestion from './components/Menus/ComplientSuggestion';
import EventScheduling from './components/Menus/EventScheduling';
import Voting from './components/Menus/Voting';
import Logout from './components/Logout';
import GotoLogin from './components/GotoLogin';
import CAccounting from './components/CMenus/CAccounting';
import CComplientSuggestion from './components/CMenus/CComplientSuggestion';
import BVoting from './components/Bulletin/BVoting';
import BEvents from './components/Bulletin/BEvents';
import BComplaints from './components/Bulletin/BComplaints';
import BSuggestions from './components/Bulletin/BSuggestions';
import CVoting from './components/Admin/CVoting';
import RegisterMember from './components/Admin/RegisterMember';
import UpdateMember from './components/Admin/UpdateMember';
import CEvent from './components/CMenus/CEvent';
import PasswordUpdate from './components/Menus/PasswordUpdate';
import Noacess from './components/Noacess';
import DeleteUser from './components/Admin/DeleteUser';
import Alert from './components/Alert';

function App() {
  const [isUserLoggedIn, setIsUserLoggedIn] =
    useRecoilState(isUserLoggedInState);
  const [userId, setUserId] = useRecoilState(userIdState);
  const [userName, setUserName] = useRecoilState(userNameState);
  const [userType, setUserType] = useRecoilState(userTypeState);
  const [isAlertShows, setalertShows] = useRecoilState(isAlert);


  useEffect(() => {
    const checkUser = async () => {
      let user
      const userToken = window.localStorage.getItem('userToken')
      if (userToken) {
        user = atob(userToken).split(' ')
        let res = await auth(user[0], user[1])
        if (res.success == 'true') {
          setIsUserLoggedIn(true)
          setUserId(user[2])
          setUserName(user[3])
          setUserType(user[4])
        }
      }
    }
    checkUser()
  }, [])

  const isAdmin = userType == 'admin' && isUserLoggedIn
  const isCommitie = userType == 'commitie' && isUserLoggedIn
  const ismember = (userType == 'commitie' || userType == 'society') && isUserLoggedIn

  return (
    <div className="App home-bg">
      <Nav />

      {
        isUserLoggedIn &&
        <Logout />
      }
      <BrowserRouter>
        <Routes>
          <Route exact path='/' Component={isUserLoggedIn ? Home : Login} />
          <Route exact path='/bulletin' Component={isUserLoggedIn ? Bulletin : GotoLogin} />
          <Route exact path='/communitywiki' Component={isUserLoggedIn ? CommunityWiki : GotoLogin} />
          <Route exact path='/voting' Component={ismember ? Voting : GotoLogin} />
          <Route exact path='/accounting' Component={ismember ? Accounting : GotoLogin} />
          <Route exact path='/complaint-suggestion' Component={ismember ? ComplientSuggestion : GotoLogin} />
          <Route exact path='/events-scheduling' Component={ismember ? EventScheduling : GotoLogin} />
          <Route exact path='/password-update' Component={ismember ? PasswordUpdate : GotoLogin} />
          {/* bulletins */}
          <Route exact path='/bulletin/results-of-voting' Component={isUserLoggedIn ? BVoting : GotoLogin} />
          <Route exact path='/bulletin/details-of-events' Component={isUserLoggedIn ? BEvents : GotoLogin} />
          <Route exact path='/bulletin/details-of-complaints' Component={isUserLoggedIn ? BComplaints : GotoLogin} />
          <Route exact path='/bulletin/details-of-suggestions' Component={isUserLoggedIn ? BSuggestions : GotoLogin} />
          {/* commitite */}
          <Route exact path='/accounting-contoller' Component={isCommitie ? CAccounting : isUserLoggedIn ? Noacess : GotoLogin} />
          <Route exact path='/complaint-suggestion-contoller' Component={isCommitie ? CComplientSuggestion : isUserLoggedIn ? Noacess : GotoLogin} />
          <Route exact path='/events-contoller' Component={isCommitie ? CEvent : isUserLoggedIn ? Noacess : GotoLogin} />
          {/* admin */}
          <Route exact path='/voting-contoller' Component={isAdmin ? CVoting : isUserLoggedIn ? Noacess : GotoLogin} />
          <Route exact path='/register-member' Component={isAdmin ? RegisterMember : isUserLoggedIn ? Noacess : GotoLogin} />
          <Route exact path='/update-member' Component={isAdmin ? UpdateMember : isUserLoggedIn ? Noacess : GotoLogin} />
          <Route exact path='/delete-member' Component={isAdmin ? DeleteUser : isUserLoggedIn ? Noacess : GotoLogin} />
          <Route exact path='*' Component={pageNotFound} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
