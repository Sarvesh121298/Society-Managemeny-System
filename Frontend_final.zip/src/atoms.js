import { atom } from 'recoil';

export const userTypeState = atom({
    key: 'userTypeState',
    default: ''
});

export const userIdState = atom({
    key: 'userIdState',
    default: ''
});

export const userNameState = atom({
    key: 'userNameState',
    default: ''
});

export const userNumberState = atom({
    key: 'userNumberState',
    default: ''
});

export const isUserLoggedInState = atom({
    key: 'isUserLoggedInState',
    default: false
})

export const isAlert = atom({
    key: 'isAlert',
    default: true
})

export const alertText = atom({
    key: 'alertText',
    default: ''
})