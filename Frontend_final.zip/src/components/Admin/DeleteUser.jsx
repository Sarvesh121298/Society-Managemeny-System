import React, { useEffect, useRef, useState } from "react";
import {
  Container,
  Form,
  Row,
  Button,
  Col,
  DropdownButton,
  Dropdown,
} from "react-bootstrap";
import { useRecoilState } from "recoil";
import { userTypeState } from "../../atoms";
import { updateMember } from "../../utils/auth";
import axios from "axios";
import BackBtn from "../BackBtn";

export default function DeleteUser() {
  const [userType, setUserType] = useRecoilState(userTypeState);

  const [members, setMembers] = useState();
  const [personName, setPersonName] = useState();
  const [person, setPerson] = useState();

  useEffect(() => {
    const getAllMembers = async () => {
      const res = await axios("http://localhost:1000/getAllMembers");
      setMembers(res.data);
    };
    getAllMembers();
  }, []);

  console.log(person);

  const submit = async (e) => {
    e.preventDefault();
    const res = await axios.delete(`http://localhost:1000/member/${person.id}`);
    console.log(res);
    if (res.data.deleted == true) {
      alert("Member deleted succesfully");
      window.location.reload();
    } else {
      alert("Something went wrong");
      window.location.reload();
    }
  };

  return (
    <Container
    style={{
      backgroundColor: "#454545",
      padding: "20px",
      margin: "50px auto",
      
      maxWidth:'550px'
      
    }}
    >
      <BackBtn />
      <br />
      <h2 style={{color:'white'}}>Delete member details</h2>
      <br />
      <Form.Group className="mb-3" controlId="formBasicName">
        <Form.Label style={{color:'white'}}>Resident Name</Form.Label>
        <DropdownButton
          id="dropdown-basic-button"
          title={
            personName ? `${personName[0]} ${personName[1]}` : "Choose Name"
          }
        >
          {members?.map((member) => {
            if (member.fname == "Admin") return;
            return (
              <Dropdown.Item
                onClick={() => {
                  setPersonName([member.fname, member.lname, member.id]);
                  setPerson(member);
                }}
              >
                {`${member.fname} ${member.lname}`}
              </Dropdown.Item>
            );
          })}
        </DropdownButton>
        <br />
        {person && (
          <Button variant="primary" type="submit" onClick={(e) => submit(e)}>
            Submit
          </Button>
        )}
      </Form.Group>
    </Container>
  );
}
