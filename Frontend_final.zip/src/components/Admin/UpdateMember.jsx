import React, { useEffect, useRef, useState } from "react";
import {
  Container,
  Form,
  Row,
  Button,
  Col,
  DropdownButton,
  Dropdown,
} from "react-bootstrap";
import { useRecoilState } from "recoil";
import { alertText, isAlert, userTypeState } from "../../atoms";
import PageNotFound from "../pageNotFound";
import { createMember, updateMember } from "../../utils/auth";
import axios from "axios";
import BackBtn from "../BackBtn";

export default function CUpdateMember() {
  const [userType, setUserType] = useRecoilState(userTypeState);

  const fnameRef = useRef();
  const mnameRef = useRef();
  const lnameRef = useRef();
  const wingnoRef = useRef();
  const flatnoRef = useRef();
  const passwordRef = useRef();
  const countRef = useRef();
  const [mType, setMType] = useState();

  const [members, setMembers] = useState();
  const [personName, setPersonName] = useState();
  const [person, setPerson] = useState();

  useEffect(() => {
    const getAllMembers = async () => {
      const res = await axios("http://localhost:1000/getAllMembers");
      setMembers(res.data);
    };
    getAllMembers();
  }, []);
  console.log(person);

  const submit = async (e) => {
    e.preventDefault();
    let data = {
      fname: fnameRef.current.value,
      mname: mnameRef.current.value,
      lname: lnameRef.current.value,
      wingno: wingnoRef.current.value,
      flatno: flatnoRef.current.value,
      count: countRef.current.value,
      password: person?.password,
      mtype: mType ? mType : person?.mType,
    };
    const res = await updateMember(personName[2], data);
    if (res.id) {
      alert("Member updated succesfully");
      window.location.reload();
    } else {
      alert("Something went wrong");
      window.location.reload();
    }
  };

  return (
    <Container
    style={{
      backgroundColor: "#454545",
      padding: "20px",
      margin: "50px auto",
      
      maxWidth:'550px'
      
    }}
    >
      <BackBtn />
      <br />
      <h2 style={{color:'white'}}>Update member details</h2>
      <br />
      <Form.Group className="mb-3" controlId="formBasicName">
        <Form.Label style={{color:'white'}}>Resident Name</Form.Label>
        <DropdownButton
          id="dropdown-basic-button"
          title={
            personName ? `${personName[0]} ${personName[1]}` : "Choose Name"
          }
        >
          {members?.map((member) => {
            if (member.fname == "Admin") return;
            return (
              <Dropdown.Item
                onClick={() => {
                  setPersonName([member.fname, member.lname, member.id]);
                  setPerson(member);
                }}
              >
                {`${member.fname} ${member.lname}`}
              </Dropdown.Item>
            );
          })}
        </DropdownButton>
      </Form.Group>
      {person && (
        <Form
          style={{
            border: "1px solid black",
            padding: "10px",
            borderRadius: "10px",
            maxWidth: "500px",
            margin: "auto",
            backgroundColor:"#FFE6C7"
          }}
        >
          <Row>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicFName">
                <Form.Label>Enter First name*</Form.Label>
                <Form.Control
                  type="text"
                  ref={fnameRef}
                  defaultValue={person.fname}
                  placeholder="Enter First Name"
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicMName">
                <Form.Label>Enter Middle name*</Form.Label>
                <Form.Control
                  type="text"
                  ref={mnameRef}
                  defaultValue={person.mname}
                  placeholder="Enter Middle Name"
                  required
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicLName">
                <Form.Label>Enter Last name*</Form.Label>
                <Form.Control
                  type="text"
                  ref={lnameRef}
                  defaultValue={person.lname}
                  placeholder="Enter Last Name"
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicEName">
                <Form.Label>Family members count*</Form.Label>
                <Form.Control
                  type="number"
                  defaultValue={person.count}
                  ref={countRef}
                  required
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicWnumber">
                <Form.Label>Enter Wing number*</Form.Label>
                <Form.Control
                  type="number"
                  ref={wingnoRef}
                  defaultValue={person.wingno}
                  placeholder="Enter Wing Number"
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicFnumber">
                <Form.Label>Enter Flat number*</Form.Label>
                <Form.Control
                  type="number"
                  ref={flatnoRef}
                  defaultValue={person.flatno}
                  placeholder="Enter Flat Number"
                  required
                />
              </Form.Group>
            </Col>
            <Form.Group className="mb-3" controlId="formBasicEName">
              <Form.Label>Choose member type*</Form.Label>
              <Form.Check
                style={{ maxWidth: "200px", margin: "auto" }}
                type="radio"
                name="mtype"
                id={"2"}
                // defaultValue={person.mtype=='society'}
                onClick={() => setMType("society")}
                label={`Resident`}
                checked={
                  !mType ? person.mtype == "society" : mType == "society"
                }
              />
              <Form.Check
                style={{ maxWidth: "200px", margin: "auto" }}
                type="radio"
                name="mtype"
                id={"1"}
                onClick={() => setMType("commitie")}
                label={`Committee`}
                checked={
                  !mType ? person.mtype == "commitie" : mType == "commitie"
                }
              />
            </Form.Group>
          </Row>
          <Button variant="primary" type="submit" onClick={(e) => submit(e)}>
            Submit
          </Button>
        </Form>
      )}
    </Container>
  );
}
