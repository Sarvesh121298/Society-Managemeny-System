import React from "react";
import { Button } from "react-bootstrap";
import { alertText, isAlert } from "../atoms";
import { useRecoilState } from "recoil";

export default function Alert() {
  const [text, setText] = useRecoilState(alertText);
  const [isAlertShows, setalertShows] = useRecoilState(isAlert);

  console.log(isAlertShows);

  const ok = () => {
    setalertShows(false);
    window.location.reload();
  };

  return (
    <div className="alert">
      <div>{text}</div>
      <Button onClick={ok}>Ok</Button>
    </div>
  );
}
