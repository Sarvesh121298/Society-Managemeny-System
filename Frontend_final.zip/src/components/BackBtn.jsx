import React from "react";
import { Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

export default function BackBtn() {
  const navigate = useNavigate();
  return (
    <div className="back">
      <Button variant="dark" onClick={() => navigate(-1)}>
        {`<-`} Back
      </Button>
    </div>
  );
}
