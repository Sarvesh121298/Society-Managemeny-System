import React, { useEffect, useState } from "react";
import { Container, Table } from "react-bootstrap";
import Backbtn from "../BackBtn";
import { getAllComplaints, members } from "../../utils/complaints";

export default function BComplaints() {
  const [allComplaints, setAllcomplaints] = useState();
  const [membersList, setMembersList] = useState();

  useEffect(() => {
    const fetchAllComplaints = async () => {
      const res = await getAllComplaints();
      setAllcomplaints(res);
    };
    fetchAllComplaints();
    const getMembers = async () => {
      const res = await members();
      setMembersList(res);
    };
    getMembers();
  }, []);

  const getName = (id) => {
    const name = membersList?.filter((member) => member.id === id);
    if (name) {
      return name[0]?.fname;
    }
  };

  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "10px",
        margin: "50px auto",
        opacity:'0.87'
      }}
    >
      <Backbtn />
      <br />
      <h2>All Complaints</h2>
      <br />
      <Table striped bordered hover>
        <thead>
          <tr>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>CId</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Date</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Solved Date</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Name</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Description</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Solution</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Status</th>
          </tr>
        </thead>
        <tbody>
          {allComplaints?.map((e) => {
            return (
              <tr>
                <td>{e.id}</td>
                <td>
                  {e.date} {e.create_time}
                </td>
                <td>{e.solved_time}</td>
                <td>{getName(e.complaintant_id)}</td>
                <td>{e.description}</td>
                <td>{e.solution}</td>
                <td style={{borderRadius:'40px',backgroundColor:'purple',color:'white',}}><b>{e.status}</b></td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </Container>
  );
}
