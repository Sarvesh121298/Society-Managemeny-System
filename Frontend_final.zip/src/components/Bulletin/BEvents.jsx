import React, { useEffect, useState } from "react";
import { Container, Table } from "react-bootstrap";
import { getEvents } from "../../utils/event";
import BackBtn from "../BackBtn";

export default function BEvents() {
  const [allComplaints, setAllcomplaints] = useState();

  useEffect(() => {
    const fetchAllComplaints = async () => {
      const res = await getEvents();
      setAllcomplaints(res);
    };
    fetchAllComplaints();
    console.log(allComplaints);
  }, []);
  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "10px",
        margin: "50px auto",
        opacity:'0.87'
      }}
    >
      <br />
      <h2>All Events</h2>
      <br />

      <Table striped bordered hover>
        <thead>
          <tr>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>EId</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Date & Time</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Event Name</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Description</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Place</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Budget</th>
          </tr>
        </thead>
        <tbody>
          {allComplaints?.map((e) => {
            if (e.status === "Approved")
              return (
                <tr>
                  <td>{e.eventid}</td>
                  <td>
                    {e.date} at {e.time}
                  </td>
                  <td>{e.eventname}</td>
                  <td style={{ maxWidth: "200px" }}>{e.description}</td>
                  <td>{e.place}</td>
                  <td>{e.budget}</td>
                </tr>
              );
          })}
        </tbody>
      </Table>
      <BackBtn />
    </Container>
  );
}
