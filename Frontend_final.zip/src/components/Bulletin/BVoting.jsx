import React, { useEffect, useState } from "react";
import { getResults, results, votingEvents } from "../../utils/election";
import { Button, Container, Modal, Table } from "react-bootstrap";
import { checkTime, isDateToday } from "../../utils/Date";
import Backbtn from "../BackBtn";
import axios from "axios";

export default function BVoting() {
  const [elections, setElections] = useState();
  const [members, setMembers] = useState();

  useEffect(() => {
    const getAllElections = async () => {
      const res = await votingEvents();
      setElections(res);
    };
    getAllElections();
    const getAllMembers = async () => {
      const res = await axios("http://localhost:1000/getAllMembers");
      setMembers(res.data);
    };
    getAllMembers();
  }, []);

  const [electionResult, setElectionResult] = useState();
  const [electionParticpants, setElectionParticpants] = useState();
  const [electionVotes, setElectionVotes] = useState();
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const getName = (id) => {
    const name = members?.filter((member) => member.id === id);
    if (name) {
      return name[0];
    }
  };

  const count = (votes) => {
    const arr = votes;
    const counts = {};

    for (let i = 0; i < arr.length; i++) {
      const num = arr[i];
      counts[num] = counts[num] ? counts[num] + 1 : 1;
    }
    return counts;
  };

  const result = async (id) => {
    const res = await getResults(id);
    const result = results(res).filter((element) => element !== 0);
    const eleVotes = res.filter((element) => element !== 0);
    const allPartipants = eleVotes.filter(
      (item, index) => eleVotes.indexOf(item) === index
    );
    const votesCount = count(eleVotes);

    setElectionVotes(votesCount);
    setElectionParticpants(allPartipants);
    setElectionResult(result);
    handleShow();
  };

  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "4px",
        margin: "70px auto",
        opacity:'0.87'
      }}
    >
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Election Results</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {electionResult?.length == 0 && <h5>No one cast their vote</h5>}
          {electionResult?.length > 2 && <h5>Tie among</h5>}
          {electionResult?.length == 2 && <h5>Tie between</h5>}
          {electionResult?.length == 1 && <h5>Winner</h5>}
          {electionResult?.map((res) => {
            let name = getName(res);
            return (
              <li style={{ fontSize: "20px" }}>
                {name?.fname} {name?.lname}
              </li>
            );
          })}
          <hr />
          {electionParticpants?.map((res) => {
            let name = getName(res);
            return (
              <li style={{ fontSize: "20px" }}>
                {name?.fname} {name?.lname} got {electionVotes[res]} vote/s
              </li>
            );
          })}
        </Modal.Body>
      </Modal>
      <br />
      <h2>Completed Election results</h2>
      <br />
      <Table striped bordered hover>
        <thead>
          <tr>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Election Id</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Election Name</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Date</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>From</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>To</th>
            <th style={{backgroundColor:' #006a4e',color:'white'}}>Results</th>
          </tr>
        </thead>
        <tbody>
          {elections?.map((e) => {
            let status;
            const isToday = isDateToday(e.date);
            if (isToday == "Today") {
              status = checkTime(e.stime, e.etime);
            } else {
              status = isToday;
            }
            if (status == "Expired")
              return (
                <tr>
                  <td>{e.evid}</td>
                  <td>{e.evname}</td>
                  <td>{e.date}</td>
                  <td>{e.stime}</td>
                  <td>{e.etime}</td>
                  <td>
                    <Button onClick={() => result(e.evid)}>Results</Button>
                  </td>
                </tr>
              );
          })}
        </tbody>
      </Table>
      <br />
      <h2>All Elections</h2>
      <br />
      <Table striped bordered hover>
        <thead>
          <tr>
            <th style={{backgroundColor:' #32CD32',color:'white'}}>Election Id</th>
            <th style={{backgroundColor:' #32CD32',color:'white'}}>Election Name</th>
            <th style={{backgroundColor:' #32CD32',color:'white'}}>Date</th>
            <th style={{backgroundColor:' #32CD32',color:'white'}}>From</th>
            <th style={{backgroundColor:' #32CD32',color:'white'}}>To</th>
            <th style={{backgroundColor:' #32CD32',color:'white'}}>Status</th>
          </tr>
        </thead>
        <tbody>
          {elections?.map((e) => {
            let status;
            const isToday = isDateToday(e.date);
            if (isToday == "Today") {
              status = checkTime(e.stime, e.etime);
            } else {
              status = isToday;
            }
            return (
              <tr>
                <td>{e.evid}</td>
                <td>{e.evname}</td>
                <td>{e.date}</td>
                <td>{e.stime}</td>
                <td>{e.etime}</td>
                <td style={{borderRadius:'40px',backgroundColor:'maroon',color:'white',}}><b>{status}</b></td>
              </tr>
            );
          })}
        </tbody>
      </Table>
      <Backbtn />
    </Container>
  );
}
