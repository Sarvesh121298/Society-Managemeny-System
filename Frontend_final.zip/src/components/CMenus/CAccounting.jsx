import React, { useEffect, useRef, useState } from "react";
import { useRecoilState } from "recoil";
import { userTypeState } from "../../atoms";
import PageNotFound from "../pageNotFound";
import {
  Button,
  Container,
  Dropdown,
  DropdownButton,
  Form,
} from "react-bootstrap";
import axios from "axios";
import { addBill } from "../../utils/AddBill";
import Backbtn from "../BackBtn";
import { KeyValueInputs } from "../KeyValueInputs";

export default function CAccounting() {
  const [userType, setUserType] = useRecoilState(userTypeState);
  const [personName, setPersonName] = useState();
  const [members, setMembers] = useState();
  const [getStringList, setStringList] = useState();
  const [keyValuePairs, setKeyValuePairs] = useState([{ key: "", value: "" }]);

  const monthRef = useRef();
  const monthDueRef = useRef();
  const generalRef = useRef();
  const buildingRef = useRef();
  const commonRef = useRef();
  const chargesRef = useRef();

  // console.log(JSON.stringify(obj));

  useEffect(() => {
    const getAllMembers = async () => {
      const res = await axios("http://localhost:1000/getAllMembers");
      setMembers(res.data);
    };
    getAllMembers();
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    let month = monthRef.current.value;
    let monthDue = monthDueRef.current.value;
    let general = generalRef.current.value;
    let building = buildingRef.current.value;
    let common = commonRef.current.value;
    let charges = chargesRef.current.value;
    let stringList = "";
    keyValuePairs.map((e) => {
      stringList += `{` + `"${e.key}` + `":` + `"${e.value}` + `"}` + ",";
    });
    console.log(stringList);

    const data = {
      mdues: monthDue,
      general: general,
      building: building,
      common: common,
      charges: charges,
      others: stringList,
    };

    const params = {
      params: {
        billmonth: month,
        fname: personName[0],
        lname: personName[1],
      },
    };

    const res = await addBill(data, params);
    if (res.billNo) {
      alert("Bill created successfully");
      window.location.reload();
    } else {
      alert("Something went wrong");
      window.location.reload();
    }
  };

  if (userType !== "commitie") {
    return <PageNotFound />;
  }
  return (
    <Container
      style={{
        maxWidth: "700px",
        backgroundColor:'#454545',
        padding: "20px",
        margin: "50px auto",
        borderRadius: "10px",
        
      }}
    >
      <Backbtn />
      <h2 style={{color:'white'}}>Create bill</h2>
      <Form
        style={{
          backgroundColor:'#FFE6C7',
          border: "1px solid black",
          padding: "10px",
          borderRadius: "10px",
        }}
      >
        <Form.Group className="mb-3" controlId="formBasicMonth">
          <Form.Label>Choose Bill month and year*</Form.Label>
          <Form.Control type="month" ref={monthRef} required />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicName">
          <Form.Label>Person Name*</Form.Label>
          <DropdownButton
            id="dropdown-basic-button"
            title={
              personName ? `${personName[0]} ${personName[1]}` : "Choose Name"
            }
          >
            {members?.map((member) => {
              if (member.fname == "Admin") return;
              return (
                <Dropdown.Item
                  onClick={() => setPersonName([member.fname, member.lname])}
                >
                  {`${member.fname} ${member.lname}`}
                </Dropdown.Item>
              );
            })}
          </DropdownButton>
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicMDues">
          <Form.Label>Month Dues</Form.Label>
          <Form.Control
            type="number"
            ref={monthDueRef}
            placeholder="Month Due"
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicGeneral">
          <Form.Label>General</Form.Label>
          <Form.Control type="number" ref={generalRef} placeholder="General" />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicBuildungMaintance">
          <Form.Label>Building Maintainance</Form.Label>
          <Form.Control
            type="number"
            ref={buildingRef}
            placeholder="Building Maintance"
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicCommonBill">
          <Form.Label>Common Bills</Form.Label>
          <Form.Control
            type="number"
            ref={commonRef}
            placeholder="Common Bill"
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicMDues">
          <Form.Label>Charges</Form.Label>
          <Form.Control type="number" ref={chargesRef} placeholder="Charges" />
        </Form.Group>
        <br />
        <KeyValueInputs
          keyValuePairs={keyValuePairs}
          setKeyValuePairs={setKeyValuePairs}
        />
        <br />
        <Button variant="primary" type="submit" onClick={(e) => submit(e)}>
          Submit
        </Button>
      </Form>
    </Container>
  );
}
