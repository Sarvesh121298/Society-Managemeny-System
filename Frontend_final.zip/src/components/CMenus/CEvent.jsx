import React, { useEffect, useState } from "react";
import { Button, Container, Table } from "react-bootstrap";
import { getEvents } from "../../utils/event";
import axios from "axios";
import BackBtn from "../BackBtn";

export default function CEvent() {
  const [allComplaints, setAllcomplaints] = useState();

  useEffect(() => {
    const fetchAllComplaints = async () => {
      const res = await getEvents();
      setAllcomplaints(res);
    };
    fetchAllComplaints();
    console.log(allComplaints);
  }, []);

  const approve = async (id) => {
    const res = await axios.put(`http://localhost:2000/event/${id}`);
    if (res.data.eventid) {
      alert("Event Approved");
      window.location.reload();
    } else {
      alert("Something went wrong");
      window.location.reload();
    }
  };
  const reject = async (id) => {
    const res = await axios.put(`http://localhost:2000/eventform/${id}`, null, {
      params: {
        status: "Reject",
      },
    });
    if (res.data.eventid) {
      alert("Event Rejected");
      window.location.reload();
    } else {
      alert("Something went wrong");
      window.location.reload();
    }
  };

  return (
    <Container
      style={{
        backgroundColor: "#009FBD",
        padding: "20px",
        margin: "50px auto",
        
      }}
    >
      <BackBtn />
      <br />
      <h2 style={{color:'white'}}>All Events</h2>
      <br />

      <Table striped bordered hover>
        <thead>
          <tr>
            <th style={{backgroundColor:' #be1515',color:'white'}}>EId</th>
            <th style={{backgroundColor:' #be1515',color:'white'}}>Date & Time</th>
            <th style={{backgroundColor:'#be1515',color:'white'}}>Name</th>
            <th style={{backgroundColor:' #be1515',color:'white'}}>Description</th>
            <th style={{backgroundColor:'#be1515',color:'white'}}>Place</th>
            <th style={{backgroundColor:' #be1515',color:'white'}}>Budget</th>
            <th style={{backgroundColor:' #be1515',color:'white'}}>Approve</th>
            <th style={{backgroundColor:' #be1515',color:'white'}}>Reject</th>
          </tr>
        </thead>
        <tbody>
          {allComplaints?.map((e) => {
            if (e.status !== "Approved" && e.status !== "Reject")
              return (
                <tr>
                  <td>{e.eventid}</td>
                  <td>
                    {e.date} at {e.time}
                  </td>
                  <td>{e.eventname}</td>
                  <td style={{ maxWidth: "200px" }}>{e.description}</td>
                  <td>{e.place}</td>
                  <td>{e.budget}</td>
                  <td>
                    <Button
                      variant="success"
                      onClick={() => approve(e.eventid)}
                    >
                      Approve
                    </Button>
                  </td>
                  <td>
                    <Button variant="danger" onClick={() => reject(e.eventid)}>
                      Reject
                    </Button>
                  </td>
                </tr>
              );
          })}
        </tbody>
      </Table>
    </Container>
  );
}
