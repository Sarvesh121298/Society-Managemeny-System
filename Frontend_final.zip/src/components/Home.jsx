import React from "react";
import { Container, Card, Row, Col } from "react-bootstrap";
import {
  Balloon,
  BalloonFill,
  CardList,
  HandIndexThumb,
  HandIndexThumbFill,
  Mailbox,
  Mailbox2,
  PersonAdd,
  PersonLock,
  PersonUp,
  PersonX,
  Receipt,
  ReceiptCutoff,
} from "react-bootstrap-icons";
import { Link } from "react-router-dom";
import { useRecoilState } from "recoil";
import { userTypeState } from "../atoms";

export default function Home() {
  const [userType, setUserType] = useRecoilState(userTypeState);

  return (
    <div>
      <Container
        style={{
          backgroundColor: "#F6E1C3",
          padding: "20px",
          margin: "50px auto",
        }}
      >
        {userType != "admin" && (
          <Row>
            <h3 style={{fontFamily:"Times New Roman"}}><b>General Menu</b></h3>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/bulletin"}
              >
                <CardList className="home-icon" />
                <Card.Header>Bulletin</Card.Header>
              </Card>
            </Col>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/voting"}
              >
                <HandIndexThumb className="home-icon" />
                <Card.Header>Voting</Card.Header>
              </Card>
            </Col>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/complaint-suggestion"}
              >
                <Mailbox className="home-icon" />
                <Card.Header>Complaint/Suggestion</Card.Header>
              </Card>
            </Col>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/accounting"}
              >
                <Receipt className="home-icon" />
                <Card.Header>Accounting</Card.Header>
              </Card>
            </Col>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/events-scheduling"}
              >
                <Balloon className="home-icon" />
                <Card.Header>Events Scheduling</Card.Header>
              </Card>
            </Col>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/password-update"}
              >
                <PersonLock className="home-icon" />
                <Card.Header>Password Update</Card.Header>
              </Card>
            </Col>
          </Row>
        )}
        {userType == "commitie" && (
          <>
            
            <h2 style={{fontFamily:"Times New Roman"}}><b>Committee Menu</b></h2>
            <Row style={{ marginTop: "50px" }}>
              <Col>
                <Card
                  style={{ margin: "30px", cursor: "pointer" }}
                  className="no-highlight"
                  as={Link}
                  to={"/accounting-contoller"}

                >
                  <ReceiptCutoff className="home-icon" />
                  <Card.Header>Accounting Controller</Card.Header>
                </Card>
              </Col>
              <Col>
                <Card
                  style={{ margin: "30px", cursor: "pointer" }}
                  className="no-highlight"
                  as={Link}
                  to={"/events-contoller"}
                >
                  <BalloonFill className="home-icon" />
                  <Card.Header>Events Controller</Card.Header>
                </Card>
              </Col>
              <Col>
                <Card
                  style={{ margin: "30px", cursor: "pointer" }}
                  className="no-highlight"
                  as={Link}
                  to={"/complaint-suggestion-contoller"}
                >
                  <Mailbox2 className="home-icon" />
                  <Card.Header>Complaint/Suggestion Controller</Card.Header>
                </Card>
              </Col>
            </Row>
          </>
        )}
        {userType == "admin" && (
          <Row>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/bulletin"}
              >
                <CardList className="home-icon" />
                <Card.Header>Bulletin</Card.Header>
              </Card>
            </Col>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/voting-contoller"}
              >
                <HandIndexThumbFill className="home-icon" />
                <Card.Header>Voting Controller</Card.Header>
              </Card>
            </Col>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/register-member"}
              >
                <PersonAdd className="home-icon" />
                <Card.Header>Create New Member</Card.Header>
              </Card>
            </Col>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/update-member"}
              >
                <PersonUp className="home-icon" />
                <Card.Header>Update Member</Card.Header>
              </Card>
            </Col>
            <Col>
              <Card
                style={{ margin: "30px", cursor: "pointer" }}
                className="no-highlight"
                as={Link}
                to={"/delete-member"}
              >
                <PersonX className="home-icon" />
                <Card.Header>Delete Member</Card.Header>
              </Card>
            </Col>
          </Row>
        )}
      </Container>
    </div>
  );
}
