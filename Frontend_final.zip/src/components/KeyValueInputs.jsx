import React, { useState } from "react";
import { Button, Col, Form, Row } from "react-bootstrap";

export function KeyValueInputs({ setKeyValuePairs, keyValuePairs }) {
  // const [keyValuePairs, setKeyValuePairs] = useState([{ key: "", value: "" }]);

  const handleKeyValuePairChange = (index, key, value) => {
    const newKeyValuePairs = [...keyValuePairs];
    newKeyValuePairs[index] = { key, value };
    setKeyValuePairs(newKeyValuePairs);
  };

  const handleAddKeyValuePair = () => {
    const lastKeyValuePair = keyValuePairs[keyValuePairs.length - 1];
    if (lastKeyValuePair.key !== "" && lastKeyValuePair.value !== "") {
      setKeyValuePairs([...keyValuePairs, { key: "", value: "" }]);
    }
  };

  const deleteItem = (index) => {
    const newList = [...keyValuePairs];
    newList.splice(index, 1);
    setKeyValuePairs(newList);
  };

  return (
    <Form>
      {keyValuePairs.map((keyValuePair, index) => (
        <Form.Group key={index}>
          <Row>
            <Col>
              <Form.Control
                type="text"
                placeholder="Service"
                value={keyValuePair.key}
                onChange={(e) =>
                  handleKeyValuePairChange(
                    index,
                    e.target.value,
                    keyValuePair.value
                  )
                }
              />
            </Col>
            <Col>
              <Form.Control
                type="number"
                placeholder="Amount"
                value={keyValuePair.value}
                onChange={(e) =>
                  handleKeyValuePairChange(
                    index,
                    keyValuePair.key,
                    e.target.value
                  )
                }
              />
            </Col>
            <Col>
              <Button variant="danger" onClick={() => deleteItem(index)}>
                Delete
              </Button>
            </Col>
            <br />
            <br />
          </Row>
        </Form.Group>
      ))}
      <br />
      <Button onClick={handleAddKeyValuePair}>Add More</Button>
    </Form>
  );
}
