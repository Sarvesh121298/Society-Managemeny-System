import React, { useRef } from "react";
import { Button, Card, Container } from "react-bootstrap";
import { useRecoilState } from "recoil";
import {
  alertText,
  isAlert,
  isUserLoggedInState,
  userIdState,
  userNameState,
  userNumberState,
  userTypeState,
} from "../atoms";
import { validateData } from "../utils/validate";
import { auth } from "../utils/auth";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [isUserLoggedIn, setIsUserLoggedIn] =
    useRecoilState(isUserLoggedInState);
  const [userId, setUserId] = useRecoilState(userIdState);
  const [userNumber, setUserNumber] = useRecoilState(userNumberState);
  const [userName, setUserName] = useRecoilState(userNameState);
  const [userType, setUserType] = useRecoilState(userTypeState);

  const numberRef = useRef();
  const passwordref = useRef();

  const navigate = useNavigate();

  const signin = async () => {
    const isValid = validateData(
      numberRef.current.value,
      passwordref.current.value
    );
    if (!isValid.valid) {
      console.log(isValid.error);
    }
    const res = await auth(numberRef.current.value, passwordref.current.value);
    console.log(res);
    if (res.success === "true") {
      setIsUserLoggedIn(true);
      setUserType(res.type);
      setUserId(res.rid);
      setUserName(res.name);
      setUserNumber(numberRef.current.value);
      window.localStorage.setItem(
        `userToken`,
        btoa(
          `${numberRef.current.value} ${passwordref.current.value} ${res.rid} ${res.name} ${res.type}`
        )
      );
      alert("Login Success");
    } else {
      alert("Invalid Details");
    }
    //reset
    numberRef.current.value = "";
    passwordref.current.value = "";
  };

  return (
    <div className="login-bg" style={{ padding: "100px" }}>
      <Card
        style={{
          maxWidth: "400px",
          margin: "auto",
          opacity:0.85,
        }}
      >
        <Card.Body>
          <Card.Title style={{fontFamily:'Times New Roman'}}><h4><b>Login</b></h4></Card.Title>
          <hr />
          <h5 style={{fontFamily:'Times New Roman'}}>Username</h5>
          <input
            placeholder="Enter Username"
            type="text"
            ref={numberRef}
            required
          />
          <h5 style={{fontFamily:'Times New Roman'}}>Password</h5>
          <input
            placeholder="Enter Password"
            type="password"
            ref={passwordref}
            required
          />
          <br />
          <br />
          <Button variant="primary" onClick={signin}>
            Sign In
          </Button>
        </Card.Body>
      </Card>
    </div>
  );
}
