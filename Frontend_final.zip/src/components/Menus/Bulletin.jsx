import React from "react";
import { Container, Card, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";
import BackBtn from "../BackBtn";

export default function Bulletin() {
  const options = [
    "Results of Voting",
    "Details of Events",
    "Details of Complaints",
    "Details of Suggestions",
  ];
  return (
    <div>
      <Container
        style={{
          backgroundColor: "#454545",
          padding: "20px",
          margin: "50px auto",
          opacity:'0.85',
          maxWidth:'550px'
          
        }}
      >
        <BackBtn />
        <h2 style={{color:'white'}}>Bulletin</h2>

        {options.map((option) => {
          let url = option.replace(/ /g, "-").toLowerCase();
          return (
            <Card
              style={{
                maxWidth: "400px",
                margin: "20px auto",
                textDecoration: "none",
                color: "black",
              }}
              as={Link}
              to={url}
            >
              <Card.Header style={{ fontSize: "24px" }}>{option}</Card.Header>
            </Card>
          );
        })}

        <Card
          // className="no-highlight"
          style={{ maxWidth: "300px", margin: "auto", fontSize: "20px" }}
          as={Link}
          to="/communitywiki"
        >
          Community WIKI
        </Card>
      </Container>
    </div>
  );
}
