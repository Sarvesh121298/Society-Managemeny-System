import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import {
  Form,
  Button,
  Container,
  DropdownButton,
  Dropdown,
} from "react-bootstrap";
import { currentTime, formattedDate } from "../../utils/Date";
import { useRecoilState } from "recoil";
import { alertText, isAlert, userIdState } from "../../atoms";
import {
  createComplaint,
  createComplaintWithoutName,
} from "../../utils/complaints";
import BackBtn from "../BackBtn";
import Alert from "../Alert";

function Complient() {
  const [members, setMembers] = useState();
  const [userId, setUserId] = useRecoilState(userIdState);

  const cmpDescriptionRef = useRef();
  const cmpSolutionRef = useRef();
  const [cmpRespondentName, setCmpRespondentName] = useState([null, null]);

  useEffect(() => {
    const getAllMembers = async () => {
      const res = await axios("http://localhost:1000/getAllMembers");
      setMembers(res.data);
    };
    getAllMembers();
  }, []);

  const cmpSubmit = async (e) => {
    e.preventDefault();
    let date = formattedDate();
    let description = cmpDescriptionRef.current.value;
    let ctime = currentTime();
    let mid = userId;
    let fname = cmpRespondentName[0];
    let lname = cmpRespondentName[1];
    let solution = cmpSolutionRef.current.value;
    console.log(fname, lname);
    if (fname == null && lname == null && description) {
      const response = await createComplaintWithoutName(
        date,
        ctime,
        description,
        mid,
        solution
      );
      if (response) {
        alert("Success, Complaint Filed");
      } else {
        alert("Failed, Something Went Wrong");
      }
      window.location.reload();
    } else if (fname && lname && description) {
      const response = await createComplaint(
        date,
        ctime,
        description,
        fname,
        lname,
        mid,
        solution
      );
      if (response) {
        alert("Success, Complaint Filed");
      } else {
        alert("Failed, Something Went Wrong");
      }
      window.location.reload();
    }
  };

  return (
    <div>
      <Form
        style={{
          backgroundColor:'#FFE6C7',
          border: "1px solid black",
          padding: "10px",
          borderRadius: "10px",
        }}
      >
        <BackBtn />
        <h3>Complaint</h3>
        <hr />
        <Form.Group className="mb-3" controlId="formBasicDescription">
          <Form.Label>Complaint Description*</Form.Label>
          <Form.Control
            as="textarea"
            rows={5}
            placeholder="Complaint Description"
            ref={cmpDescriptionRef}
            required
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicSolution">
          <Form.Label>Solution</Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            placeholder="Solution..."
            ref={cmpSolutionRef}
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicRespondent">
          <Form.Label>Against</Form.Label>
          <DropdownButton
            id="dropdown-basic-button"
            title={
              cmpRespondentName
                ? cmpRespondentName[0] + " " + cmpRespondentName[1]
                : "Choose Name"
            }
          >
            {members?.map((member) => {
              if (member.fname == "Admin") return;
              return (
                <Dropdown.Item
                  onClick={() =>
                    setCmpRespondentName([member.fname, member.lname])
                  }
                >
                  {member.fname} {member.lname}
                </Dropdown.Item>
              );
            })}
          </DropdownButton>
        </Form.Group>
        <Button variant="primary" type="submit" onClick={(e) => cmpSubmit(e)}>
          Submit
        </Button>
      </Form>
    </div>
  );
}

function Suggestion() {
  const [userId, setUserId] = useRecoilState(userIdState);
  const descriptionRef = useRef();
  const submit = async (e) => {
    e.preventDefault();
    if (
      descriptionRef.current.value !== null &&
      descriptionRef.current.value !== ""
    ) {
      const res = await axios.post(`http://localhost:4000/suggestion`, null, {
        params: {
          date: formattedDate(),
          description: descriptionRef.current.value,
          rid: userId,
        },
      });
      if (res.data.id) {
        alert("Suggestion added succesfully");
        window.location.reload();
      } else {
        alert("Failed! Something went wrong");
        window.location.reload();
      }
    }
  };
  return (
    <div>
      <Form
        style={{
          backgroundColor:'',
          border: "1px solid white",
          padding: "10px",
          borderRadius: "10px",
        }}
      >
        <h3 style={{color:'white'}}>Suggestion</h3>
        <hr />
        <Form.Group className="mb-3" controlId="form2BasicDescription">
          <Form.Label style={{color:'white'}}>Suggestion Description</Form.Label>
          <Form.Control
            as="textarea"
            ref={descriptionRef}
            placeholder="Suggestion/Idea ....."
            rows={5}
            required
          />
        </Form.Group>
        <Button variant="primary" type="submit" onClick={(e) => submit(e)}>
          Submit
        </Button>
      </Form>
    </div>
  );
}

export default function ComplientSuggestion() {
  const [formType, setFormType] = useState("complient");
  return (
    <div>
      <Container
        style={{
          backgroundColor:'#454545',
          padding: "20px",
          margin: "50px auto",
          maxWidth: "500px",
          borderRadius:'10%'
        }}
      >
        <h2 style={{color:'white'}}>Complaint and Suggestion</h2>
        <hr />
        <Button onClick={() => setFormType("complient")} className="mb-3">
          Complaint
        </Button>{" "}
        <Button onClick={() => setFormType("suggestion")} className="mb-3">
          Suggestion
        </Button>
        {formType == "complient" && <Complient />}
        {formType == "suggestion" && <Suggestion />}
      </Container>
    </div>
  );
}
