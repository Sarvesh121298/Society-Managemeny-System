import React from "react";
import { Navbar } from "react-bootstrap";

export default function Nav() {
  return (
    <div>
      <Navbar
        style={{
          position: "sticky",
          top: "0",
          zIndex: "2",
          color: "white",
          justifyContent: "space-between",
          padding: "10px",
          backgroundColor: "maroon",
        }}
        expand="lg"
        variant="dark"
      >
        <Navbar.Brand href="/" style={{fontFamily:'Montserrat'}}><h4><b>Society Management System</b></h4></Navbar.Brand>
      </Navbar>
    </div>
  );
}
