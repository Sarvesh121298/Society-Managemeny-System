import React from "react";

export default function Noacess() {
  return (
    <div
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
        maxWidth: "300px",
      }}
    >
      <h3>No Access</h3>
    </div>
  );
}
