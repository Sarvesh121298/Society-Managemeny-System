import React from "react";

export default function PageNotFound() {
  return (
    <div
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
        maxWidth: "300px",
      }}
    >
      <h3>404 Not Found</h3>
    </div>
  );
}
