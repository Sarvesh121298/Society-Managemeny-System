import axios from "axios"

export const addBill = async (data, params) => {
    const res = await axios.post(`http://localhost:5000/generatebill`, data, params)
    return res.data
}