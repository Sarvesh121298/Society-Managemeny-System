export const formattedDate = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    let mm = today.getMonth() + 1; // Months start at 0!
    let dd = today.getDate();

    if (dd < 10) dd = '0' + dd;
    if (mm < 10) mm = '0' + mm;

    const formattedToday = dd + '-' + mm + '-' + yyyy;
    return formattedToday
}

export function isDateToday(date) {
    // Get the current date
    const today = new Date();

    // Convert the given date string to a Date object
    const givenDate = new Date(date);

    today.setHours(0, 0, 0, 0);
    givenDate.setHours(0, 0, 0, 0);

    // Compare the two dates
    if (givenDate.getTime() === today.getTime()) {
        return 'Today'
    } else if (givenDate < today) {
        return 'Expired'
    } else {
        return 'Upcoming'
    }
}

export
    function checkTime(start, end) {
    // Get the current date
    const today = new Date();

    // Set the start and end times
    const startParts = start.split(':');
    const startTime = new Date(today.getFullYear(), today.getMonth(), today.getDate(), startParts[0], startParts[1]).getTime();
    const endParts = end.split(':');
    const endTime = new Date(today.getFullYear(), today.getMonth(), today.getDate(), endParts[0], endParts[1]).getTime();

    // Get the current time
    const currentTime = today.getTime();

    // console.log(startTime, endTime)
    // Compare the times
    if (currentTime >= startTime && currentTime <= endTime) {
        return 'Ongoing'
    } else if (currentTime < startTime) {
        return 'Upcoming'
    } else {
        return 'Expired'
    }
}


export const dateAndTime = () => {
    const options = {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: 'numeric',
        minute: 'numeric'
    };
    const formattedDate = new Date().toLocaleString('en-US', options);
    return formattedDate
}

export const currentTime = () => {
    const date = new Date();
    let hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'pm' : 'am';

    // Convert to 12-hour format
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'

    const formattedTime = hours + ':' + minutes + ' ' + ampm;
    return formattedTime
}