import axios from "axios";

export const auth = async (uid, password) => {
    const res = await axios.post(`http://localhost:1000/mlogin`, null, {
        params: {
            uid: uid,
            password: password
        }
    }).then(response => response.data);
    return res
}

export const logout = () => {
    console.log('first')
    window.localStorage.removeItem(`userToken`)
    window.location.reload();
}

export const createMember = async (data) => {
    const res = await axios.post(`http://localhost:1000/member?count=${data.count}&flatno=${data.flatno}&fname=${data.fname}&lname=${data.lname}&mname=${data.mname}&mtype=${data.mtype}&number=${data.number}&password=${data.password}&wingno=${data.wingno}`).then(response => response.data);
    return res
}

export const updateMember = async (id, data) => {
    const res = await axios.put(`http://localhost:1000/member/${id}`, data).then(response => response.data);
    return res
}