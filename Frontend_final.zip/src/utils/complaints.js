import axios from "axios";

export const createComplaint = async (date, ctime, description, fname, lname, rid, solution = null) => {
    const res = await axios.post(`http://localhost:4000/complaint`, null, {
        params: {
            date: date,
            ctime: ctime,
            description: description,
            fname: fname,
            lname: lname,
            rid: rid,
            solution: solution
        }
    }).then(response => response.data);
    if (res.id) {
        return true
    }
    else {
        return false
    }
}

export const createComplaintWithoutName = async (date, ctime, description, rid, solution = null) => {
    const res = await axios.post(`http://localhost:4000/complaint`, null, {
        params: {
            date: date,
            ctime: ctime,
            description: description,
            rid: rid,
            solution: solution
        }
    }).then(response => response.data);
    if (res.id) {
        return true
    }
    else {
        return false
    }
}

export const members = async () => {
    const res = await axios.get(`http://localhost:1000/getAllMembers`).then(response => response.data);
    return res;
}

export const getComplaints = async () => {
    const res = await axios.get(`http://localhost:4000/getcomplaint`).then(response => response.data);
    return res;
}

export const getSuggestions = async () => {
    const res = await axios.get(`http://localhost:4000/getpendingsuggestion`).then(response => response.data);
    return res;
}

export const getAllComplaints = async () => {
    const res = await axios.get(`http://localhost:4000/getAllcomplaints`).then(response => response.data);
    return res;
}

export const getAllsuggestions = async () => {
    const res = await axios.get(`http://localhost:4000/getAllsuggestions`).then(response => response.data);
    return res;
}