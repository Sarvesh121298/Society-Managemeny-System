import axios from "axios";

export const createEvent = async (data, userType) => {
    let res = await axios.post(`http://localhost:2000/events`, {
        eventname: data.name,
        place: data.place,
        budget: data.budget,
        date: data.date,
        time: data.time,
        description: data.description,
        rid: data.rid,
        rnumber: data.rnumber,
    }).then(response => response.data);
    console.log(res)
    if (userType == 'commitie') {
        const newRes = await axios.put(`http://localhost:2000/event/${res.eventid}`);
        return newRes.data

    }
    return res
}

export const getEvents = async () => {
    const res = await axios.get(`http://localhost:2000/getAll`).then(response => response.data);
    return res;
}